from tkinter import *
import math

class ScientificCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Scientific Calculator")
        self.root.geometry("400x600")
        self.root.config(bg="#121212")
        self.root.resizable(False, False)

        self.expression = ""
        self.input_text = StringVar()

        # ================= DISPLAY =================
        input_frame = Frame(self.root, bg="#121212")
        input_frame.pack(expand=True, fill="both")

        self.input_field = Entry(
            input_frame,
            font=('Consolas', 24, 'bold'),
            textvariable=self.input_text,
            bg="#1f1f1f",
            fg="#00ffcc",
            bd=0,
            justify=RIGHT
        )
        self.input_field.pack(fill="both", ipadx=8, ipady=30)

        # ================= BUTTON FRAME =================
        btns_frame = Frame(self.root, bg="#121212")
        btns_frame.pack(expand=True, fill="both")

        # Grid setup
        for i in range(7):
            btns_frame.rowconfigure(i, weight=1)
        for j in range(5):
            btns_frame.columnconfigure(j, weight=1)

        # ================= FUNCTIONS =================
        def click(value):
            self.expression += str(value)
            self.input_text.set(self.expression)

        def clear():
            self.expression = ""
            self.input_text.set("")

        def backspace():
            self.expression = self.expression[:-1]
            self.input_text.set(self.expression)

        def equal():
            try:
                result = str(eval(self.expression))
                self.input_text.set(result)
                self.expression = result
            except:
                self.input_text.set("Error")
                self.expression = ""

        def sqrt():
            try:
                result = math.sqrt(eval(self.expression))
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def square():
            try:
                result = eval(self.expression) ** 2
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def sin():
            try:
                result = math.sin(math.radians(eval(self.expression)))
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def cos():
            try:
                result = math.cos(math.radians(eval(self.expression)))
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def tan():
            try:
                result = math.tan(math.radians(eval(self.expression)))
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def log():
            try:
                result = math.log10(eval(self.expression))
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def ln():
            try:
                result = math.log(eval(self.expression))
                self.input_text.set(result)
                self.expression = str(result)
            except:
                self.input_text.set("Error")

        def pi():
            self.expression += str(math.pi)
            self.input_text.set(self.expression)

        def e():
            self.expression += str(math.e)
            self.input_text.set(self.expression)

        # ================= BUTTON CREATOR =================
        def create_btn(text, row, col, cmd, bg="#2d2d2d", fg="white"):
            Button(
                btns_frame,
                text=text,
                command=cmd,
                font=('Arial', 12, 'bold'),
                bd=0,
                bg=bg,
                fg=fg,
                activebackground="#444",
                activeforeground="white"
            ).grid(row=row, column=col, sticky="nsew", padx=1, pady=1)

        # ================= SCIENTIFIC ROW =================
        create_btn("sin", 0, 0, sin, "#3a3a3a")
        create_btn("cos", 0, 1, cos, "#3a3a3a")
        create_btn("tan", 0, 2, tan, "#3a3a3a")
        create_btn("√", 0, 3, sqrt, "#3a3a3a")
        create_btn("x²", 0, 4, square, "#3a3a3a")

        create_btn("log", 1, 0, log, "#3a3a3a")
        create_btn("ln", 1, 1, ln, "#3a3a3a")
        create_btn("π", 1, 2, pi, "#3a3a3a")
        create_btn("e", 1, 3, e, "#3a3a3a")
        create_btn("C", 1, 4, clear, "#ff4d4d")

        # ================= NORMAL KEYS =================
        nums = [
            ('7',2,0), ('8',2,1), ('9',2,2), ('/',2,3),
            ('4',3,0), ('5',3,1), ('6',3,2), ('*',3,3),
            ('1',4,0), ('2',4,1), ('3',4,2), ('-',4,3),
            ('0',5,0), ('.',5,1), ('+',5,2)
        ]

        for (text, row, col) in nums:
            create_btn(text, row, col, lambda t=text: click(t))

        create_btn("⌫", 2, 4, backspace, "#ff4d4d")
        create_btn("=", 5, 3, equal, "#00cc66")

        # Footer
        Label(
            self.root,
            text="Scientific Calculator | Python Tkinter",
            bg="#121212",
            fg="gray",
            font=("Arial", 10)
        ).pack(pady=5)


# ================= RUN APP =================
root = Tk()
app = ScientificCalculator(root)
root.mainloop()
