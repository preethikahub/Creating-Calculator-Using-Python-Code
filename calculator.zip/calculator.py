from tkinter import *

class AdvancedCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Calculator")
        self.root.geometry("320x520")
        self.root.config(bg="#1e1e1e")
        self.root.resizable(False, False)

        self.expression = ""
        self.input_text = StringVar()

        # Display Frame
        input_frame = Frame(self.root, bg="#1e1e1e")
        input_frame.pack(expand=True, fill="both")

        # Display Entry
        self.input_field = Entry(
            input_frame,
            font=('Arial', 24, 'bold'),
            textvariable=self.input_text,
            bg="#2d2d2d",
            fg="white",
            bd=0,
            justify=RIGHT
        )
        self.input_field.pack(fill="both", ipadx=8, ipady=25)

        # Buttons Frame
        btns_frame = Frame(self.root, bg="#1e1e1e")
        btns_frame.pack(expand=True, fill="both")

        # Button Style Function
        def create_button(text, row, col, cmd, bg="#333", fg="white"):
            button = Button(
                btns_frame,
                text=text,
                command=cmd,
                font=('Arial', 14, 'bold'),
                bd=0,
                fg=fg,
                bg=bg,
                activebackground="#555",
                activeforeground="white"
            )
            button.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)

        # Grid Configuration
        for i in range(6):
            btns_frame.rowconfigure(i, weight=1)
        for j in range(4):
            btns_frame.columnconfigure(j, weight=1)

        # Button Actions
        def click(item):
            self.expression += str(item)
            self.input_text.set(self.expression)

        def clear():
            self.expression = ""
            self.input_text.set("")

        def backspace():
            self.expression = self.expression[:-1]
            self.input_text.set(self.expression)

        def equal():
            try:
                result = str(eval(self.expression))
                self.input_text.set(result)
                self.expression = result
            except:
                self.input_text.set("Error")
                self.expression = ""

        # Row 0
        create_button("C", 0, 0, clear, "#ff4d4d")
        create_button("⌫", 0, 1, backspace, "#ff4d4d")
        create_button("%", 0, 2, lambda: click('%'), "#ffa500")
        create_button("/", 0, 3, lambda: click('/'), "#ffa500")

        # Row 1
        create_button("7", 1, 0, lambda: click(7))
        create_button("8", 1, 1, lambda: click(8))
        create_button("9", 1, 2, lambda: click(9))
        create_button("*", 1, 3, lambda: click('*'), "#ffa500")

        # Row 2
        create_button("4", 2, 0, lambda: click(4))
        create_button("5", 2, 1, lambda: click(5))
        create_button("6", 2, 2, lambda: click(6))
        create_button("-", 2, 3, lambda: click('-'), "#ffa500")

        # Row 3
        create_button("1", 3, 0, lambda: click(1))
        create_button("2", 3, 1, lambda: click(2))
        create_button("3", 3, 2, lambda: click(3))
        create_button("+", 3, 3, lambda: click('+'), "#ffa500")

        # Row 4
        create_button("0", 4, 0, lambda: click(0))
        create_button(".", 4, 1, lambda: click('.'))
        create_button("=", 4, 2, equal, "#00cc66")
        create_button("", 4, 3, lambda: None)

        # Footer
        footer = Label(
            self.root,
            text="Advanced Calculator",
            bg="#1e1e1e",
            fg="gray",
            font=("Arial", 10)
        )
        footer.pack(side=BOTTOM, pady=5)


# Run App
root = Tk()
app = AdvancedCalculator(root)
root.mainloop()
